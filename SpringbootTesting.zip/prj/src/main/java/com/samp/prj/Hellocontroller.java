package com.samp.prj;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hellocontroller {

	@GetMapping("/hello")
	public String gethello(@RequestParam(name="name",defaultValue ="wel" ) String name ) {
		return "welcome hello "+name;
	}
	
	@PostMapping("/hello")
	public String hellopost() {
		return "welcome hello post call";
	}
	
	@PutMapping("/hello")
	public String helloput() {
		return "welcome hello put call";
	}
	@DeleteMapping("/hello")
	public String hellodelete() {
		return "welcome hello Delete call";
	}
}
