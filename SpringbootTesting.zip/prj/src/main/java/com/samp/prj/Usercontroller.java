package com.samp.prj;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.samp.entity.User;
import com.samp.service.UserService;

@RestController
public class Usercontroller {
	
	@Autowired
	UserService userservice;
	
	@GetMapping("user/{id}")
	public ResponseEntity<User> getUserid(@PathVariable Integer id){
		
		return new ResponseEntity<>(userservice.getuserbyId(id),HttpStatus.OK);
	}
	
	@PostMapping("/postuser")
	public ResponseEntity<User> saveuser(@RequestBody User user){
		
		return new ResponseEntity<>(userservice.saveuser(user),HttpStatus.CREATED);
	}
	
	@DeleteMapping("delete/{id}")
	public String deleteUserid(@PathVariable Integer id){
		
		 userservice.deleteuser(id);
		 
		 return "User successfully deleted";
	}
	
	
	@PutMapping("/update")
	public ResponseEntity<User> updateUser(@RequestBody User user){
		
		return new ResponseEntity<>(userservice.updateuser(user),HttpStatus.ACCEPTED);
	}

}
