package com.samp.prj;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Productcontroller {
	
	@GetMapping("/product")
	public Product getproduct() {
		Product d=new Product(1,"mobile",5000);
		return d;
	}

	@GetMapping("/products")
	public List<Product> getproducts() {
		List<Product> prod=new ArrayList<Product>();
		prod.add(new Product(1,"mobile",5000));
		prod.add(new Product(2,"phone",10000));
		
		return prod;
	}
	
	@PostMapping("/addproduct")
	public ResponseEntity<Product> addproduct(@RequestBody Product product) {
		System.out.println(product);
		return new ResponseEntity<Product>(HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/products/{id}")
	public ResponseEntity<Product> getproductid(@PathVariable int id) {
		
		if(id==2) {
		Product d=new Product(1,"mobile",5000);
		return new ResponseEntity<Product>(d,HttpStatus.ACCEPTED);
		}
		return new ResponseEntity<Product>(HttpStatus.OK);
	}

}
