package com.samp.repository;

import com.samp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
public interface userRepository extends JpaRepository <User,Integer> {

}
