package com.samp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.samp.entity.User;
import com.samp.repository.userRepository;

@Service
public class Userserviceimpl implements UserService{
	
	@Autowired
	private userRepository userRepository;

	@Override
	public User getuserbyId(Integer id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id).get();
	}

	@Override
	public User saveuser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@Override
	public void deleteuser(Integer d) {
		// TODO Auto-generated method stub
		 userRepository.deleteById(d);
	}

	@Override
	public User updateuser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
		
		
	}

	
	
}
