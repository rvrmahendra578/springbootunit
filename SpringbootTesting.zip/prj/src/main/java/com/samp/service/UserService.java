package com.samp.service;

import com.samp.entity.User;

public interface UserService {

	public User getuserbyId(Integer id);

	public User saveuser(User user);

	public void deleteuser(Integer id);
	
	public User updateuser(User user);
}
