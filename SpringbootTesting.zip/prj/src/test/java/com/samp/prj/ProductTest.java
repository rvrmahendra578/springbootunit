package com.samp.prj;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.event.annotation.BeforeTestMethod;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment= SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ProductTest {
	
	@LocalServerPort
	private int port;
	
	TestRestTemplate restTemplate=new TestRestTemplate();
	
	HttpHeaders headers=new HttpHeaders();
	
	
	
	
	//@Test
	void testproduct() throws Exception {
		
		HttpEntity<String> entity=new HttpEntity<String>(null,headers);
		
		ResponseEntity<String> response= restTemplate.exchange("http://localhost:"+port+"/product",HttpMethod.GET,entity, String.class);
		
		System.out.println("response---------"+response.getBody());
		
		String expected="{\"id\":1,\"name\":\"mobile\",\"price\":5000}";
		
		JSONAssert.assertEquals(expected, response.getBody(), false);
		
		
	}
	
	@Test
	void testpostproduct() throws Exception {
		
		Product d=new Product(6,"mobile6",6000);
		HttpEntity<Product> entity=new HttpEntity<Product>(d,headers);
		
		ResponseEntity<String> response= restTemplate.exchange("http://localhost:"+port+"//addproduct",HttpMethod.POST,entity, String.class);
		
		System.out.println("response---------"+response);
		
		String expected="{\"id\":1,\"name\":\"mobile\",\"price\":5000}";
		
		//JSONAssert.assertEquals(expected, response.getBody(), false);
		
		
	}
	
}
