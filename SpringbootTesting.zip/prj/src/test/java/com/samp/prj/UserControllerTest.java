package com.samp.prj;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.samp.entity.User;
import com.samp.service.UserService;

@WebMvcTest(Usercontroller.class)
public class UserControllerTest {

	
	@Autowired
	Usercontroller usercontroller;
	
	@Autowired
	MockMvc mockmvc;
	
	@MockBean
	private UserService userService;
	
	
	
	//@Test
	public void getuserbyid() throws Exception {
		User user=new User();
		user.setEmail("a@a.com");
		user.setGender("male");
		user.setName("aa");
		user.setPhone("2334556677");
		when(userService.getuserbyId(anyInt())).thenReturn(user);
		
		mockmvc.perform(MockMvcRequestBuilders.get("/user/12"))
		.andDo(print())
		.andExpect(MockMvcResultMatchers.jsonPath("$.name").value("aa"))
		.andExpect(status().isOk());
		
	}
	
	
	//@Test
	public void saveuserdetails() throws Exception {
		User user=new User();
		user.setId(1);
		user.setEmail("a112@a.com");
		user.setGender("male");
		user.setName("sdd");
		user.setPhone("1234556677");
		when(userService.saveuser(any(User.class))).thenReturn(user);
		
		mockmvc.perform(MockMvcRequestBuilders.post("/postuser").content(new ObjectMapper().writeValueAsString(user))
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isCreated())
		.andExpect(MockMvcResultMatchers.jsonPath("$.id").exists());
	}
	
	//@Test
	public void deleteuserdetails() throws Exception {
		User user=new User();
		user.setId(1);
		user.setEmail("a112@a.com");
		user.setGender("male");
		user.setName("sddelete");
		user.setPhone("1234556677");
		when(userService.saveuser(any(User.class))).thenReturn(user).thenReturn(null);
		
		mockmvc.perform(MockMvcRequestBuilders.delete("/delete/1")).andDo(print())
		.andExpect(status().isOk())
		.toString().equals("User successfully deleted");
	}
	
	
	@Test
	public void updateuserdetails() throws Exception {
		User user=new User();
		user.setId(1);
		user.setEmail("a113@a.com");
		user.setGender("male");
		user.setName("sdupdate");
		user.setPhone("1234556677");
		when(userService.updateuser(any(User.class))).thenReturn(user);
		
		mockmvc.perform(MockMvcRequestBuilders.put("/update").content(new ObjectMapper().writeValueAsString(user))
				.contentType(MediaType.APPLICATION_JSON)).andDo(print())
		.andExpect(status().isAccepted())
		.andExpect(MockMvcResultMatchers.jsonPath("$.name").value("sdupdate"));
	}
}
